<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Articles extends CI_Controller {

    public function index() {
        $data['articles'] = $this->article_model->get_articles();
        $data['title'] = 'Latest Articles';

        $this->load->view('template/admin/header');
        $this->load->view('articles/index', $data);
        $this->load->view('template/admin/footer');
    }
}
