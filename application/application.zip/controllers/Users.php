<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
    }

    // List users
    public function index() {
        // Get users from the model
		$data['users'] = $this->User_model->get_users_with_authors();

        // Sort users by their complete names alphabetically (A-Z)
        usort($data['users'], function($a, $b) {
            return strcmp($a['complete_name'], $b['complete_name']);
        });

        // Set the title
        $data['title'] = 'User Management';

        // Load views
        $this->load->view('template/admin/header');
        $this->load->view('users/index', $data);
        $this->load->view('template/admin/footer');
    }

    // View user details
    public function view_details($userid) {
        // Get user data by user$userid
        $data['user'] = $this->User_model->get_user_by_id($userid);
        if (!$data['user']) {
            show_404(); // Return 404 error if the user is not found
        }
        
        // Set the title
        $data['title'] = 'User Profile';

        // Load views
        $this->load->view('template/admin/header');
        $this->load->view('users/view_details', $data);
        $this->load->view('template/admin/footer');
    }

		// EDIT
		public function update_profile($userid) {
			// Retrieve user data using user ID
			$data['user'] = $this->User_model->get_user_by_id($userid);
		
			// Initialize user data array
			$userData = [
				'complete_name' => $this->input->post('complete_name'),
				'email' => $this->input->post('email'),
				'profile_pic' => $data['user']['profile_pic'], // Default to existing profile_pic
			];
		
			// Handle form submission
			if ($_SERVER['REQUEST_METHOD'] === 'POST') {
				$contactNum = $this->input->post('contact_num');
		
				// Handle file upload
				$config['upload_path'] = 'assets/images/users/'; // Specify the directory where you want to save the images
				$config['allowed_types'] = 'jpg|jpeg|png|gif';
				$config['max_size'] = '2048'; // Maximum file size in kilobytes
		
				$this->load->library('upload', $config);
		
				if ($this->upload->do_upload('profile_pic')) {
					// Get file data
					$fileData = $this->upload->data();
					$filename = $fileData['file_name'];
					$filePath = $config['upload_path'] . $filename;
		
					// Check if a file with the same filename exists
					if (file_exists($filePath)) {
						// Remove the existing file
						unlink($filePath);
					}
		
					// Move the uploaded file to the specified directory
					if ($this->upload->do_upload('profile_pic')) {
						// Update the user data with the filename
						$userData['profile_pic'] = $filename;
					} else {
						// If there was an error during file upload, set a flash error message
						$this->session->set_flashdata('error', $this->upload->display_errors());
						redirect('users/edit/' . $userid);
						return;
					}
				}
		
				// Update user data in the database
				$userUpdateResult = $this->User_model->update_user($userid, $userData);
		
				// Update contact number in the authors table
				$authorData = ['contact_num' => $contactNum];
				$authorUpdateResult = $this->Author_model->update_author($userid, $authorData);
		
				// Handle success and failure cases
				if ($userUpdateResult && $authorUpdateResult) {
					$this->session->set_flashdata('success', 'User profile updated successfully.');
				} else {
					$this->session->set_flashdata('error', 'Failed to update user profile.');
				}
		
				// Redirect to a relevant page
				redirect('users');
			}
		
			// Load the view with user data
			$this->load->view('template/admin/header');
			$this->load->view('users/edit', $data);
			$this->load->view('template/admin/footer');
		}
		
		
		
		// Log in user
		public function login(){
			$data['title'] = 'Sign In';
		
			$this->form_validation->set_rules('email', 'Email', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');
		
			if($this->form_validation->run() === FALSE){
				$this->load->view('template/admin/header');
				$this->load->view('register/login', $data);
				$this->load->view('templates/admin/footer');
			} else {
				// Get email and encrypt the password
				$email = $this->input->post('email');
				$password = md5($this->input->post('password'));
		
				// Login user
				$user = $this->user_model->login($email, $password);
		
				if($user){
					// Create session
					$user_data = array(
						'userid' => $user['userid'],
						'email' => $email,
						'complete_name' => $user['complete_name'],
						'logged_in' => true
					);
		
					$this->session->set_userdata($user_data);
		
					// Set message
					$this->session->set_flashdata('user_loggedin', 'You are now logged in');
		
					redirect('posts');
				} else {
					// Set message
					$this->session->set_flashdata('login_failed', 'Login is invalid');
		
					redirect('register/login');
				}
			}
		}
	}
		


		// public function register(){
			//     $data['title'] = 'Sign Up';

			//     $this->form_validation->set_rules('name', 'Name', 'required');
			//     $this->form_validation->set_rules('email', 'Email', 'required|callback_check_email_exists');
			//     $this->form_validation->set_rules('password', 'Password', 'required');

			//     if($this->form_validation->run() === FALSE){
				//         $this->load->view('templates/header');
				//         $this->load->view('register/registration', $data);
				//         $this->load->view('templates/footer');
				//     } else {
					//         // Encrypt password
					//         $enc_password = md5($this->input->post('password'));

					//         $this->user_model->register($enc_password);

					//         // Set message
					//         $this->session->set_flashdata('user_registered', 'You are now registered and can log in');

					//         redirect('posts');
					//     }
					// }

					// // Log in user
					// public function login(){
						//     $data['title'] = 'Sign In';

						//     $this->form_validation->set_rules('email', 'email', 'required');
						//     $this->form_validation->set_rules('password', 'Password', 'required');

						//     if($this->form_validation->run() === FALSE){
							//         $this->load->view('templates/header');
							//         $this->load->view('users/login', $data);
							//         $this->load->view('templates/footer');
							//     } else {
								
								//         // Get username
								//         $username = $this->input->post('email');
								//         // Get and encrypt the password
								//         $password = md5($this->input->post('password'));

								//         // Login user
								//         $userid = $this->user_model->login($email, $password);

								//         if($userid){
									//             // Create session
									//             $user_data = array(
									//                 'user$userid' => $userid,
									//                 'username' => $email,
									//                 'logged_in' => true
									//             );

									//             $this->session->set_userdata($user_data);

									//             // Set message
									//             $this->session->set_flashdata('user_loggedin', 'You are now logged in');

									//             redirect('posts');
									//         } else {
										//             // Set message
										//             $this->session->set_flashdata('login_failed', 'Login is invalid');

										//             redirect('users/login');
										//         }		
										//     }
										// }

										// // Log user out
										// public function logout(){
											//     // Unset user data
											//     $this->session->unset_userdata('logged_in');
											//     $this->session->unset_userdata('userid');
											//     $this->session->unset_userdata('email');

											//     // Set message
											//     $this->session->set_flashdata('user_loggedout', 'You are now logged out');

											//     redirect('users/login');
											// }

											// // Check if username exists
											// public function check_email_exists($email){
												//     $this->form_validation->set_message('check_username_exists', 'That username is taken. Please choose a different one');
												//     if($this->user_model->check_email_exists($email)){
													//         return true;
													//     } else {
														//         return false;
														//     }
														// }

														// // Check if email exists
														// public function check_email_exists($email){
															//     $this->form_validation->set_message('check_email_exists', 'That email is taken. Please choose a different one');
															//     if($this->user_model->check_email_exists($email)){
																//         return true;
																//     } else {
																	//         return false;
																	//     }
																	// }
																// }





																// <?php
																	// defined('BASEPATH') OR exit('No direct script access allowed');

																	// class Users extends CI_Controller {

																		//     public function __construct() {
																			//         parent::__construct();
																			//         $this->load->model('User_model');
																			//     }

																			//     public function index() {
																				//         $data['users'] = $this->user_model->get_users();

																				//         $this->load->view('template/admin/header');
																				//         $this->load->view('users/index', $data);
																				//         $this->load->view('template/admin/footer');
																				
																				//     }

																				//     public function view($id) {
																					//         $data['user'] = $this->user_model->get_users($id);
																					//         $this->load->view('template/admin/header');
																					//         $this->load->view('users/index', $data);
																					//         $this->load->view('template/admin/footer');
																					//     }
																					// }

