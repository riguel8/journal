<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authors extends CI_Controller {

    public function index() {
        // Get users from the model
        $data['authors'] = $this->author_model->get_authors();
		
    
        // Sort users by their complete names alphabetically (A-Z)
        usort($data['authors'], function($a, $b) {
            return strcmp($a['author_name'], $b['author_name']);
        });
    
        // Set the title
        $data['title'] = 'Author Management';
    
        // Load views
        $this->load->view('template/admin/header');
        $this->load->view('authors/index', $data);
        $this->load->view('template/admin/footer');
    }

        // VIEW PROFILE
		public function view_details($auID) {
			// Retrieve userid from the URL
			$auID = $this->uri->segment(3); // Assuming it's the third segment in the URL

			// Load user data based on userid
			$data['author'] = $this->author_model->get_author_by_id($auID);
			$data['title'] = 'View Profile'; // Change the title as needed

			// Load views
			$this->load->view('template/admin/header');
			$this->load->view('authors/view', $data); // Fixed the parameter here
			$this->load->view('template/admin/footer');
		}  

		// EDIT
		public function edit($auID) {
			// Retrieve userid from the URL
			$auID = $this->uri->segment(3); // Assuming it's the third segment in the URL

			// Load user data based on userid
			$data['author'] = $this->author_model->get_author_by_id($auID);
			$data['title'] = 'Edit Profile'; // Change the title as needed

			// Load views
			$this->load->view('template/admin/header');
			$this->load->view('authors/edit', $data); // Fixed the parameter here
			$this->load->view('template/admin/footer');
		}  
}