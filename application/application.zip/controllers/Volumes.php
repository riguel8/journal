<?php
    class Volumes extends CI_Controller{
        public function index(){
            $data['title'] = 'Volume Lists';

            $data['volumes'] = $this->volume_model->get_volumes();
            // print_r($data['volumes']);

            $this->load->view('template/admin/header');
			$this->load->view('volumes/index', $data);
			$this->load->view('template/admin/footer');
        }
    }