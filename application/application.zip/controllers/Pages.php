<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {

    public function view($page = 'home') {
        $data['articles'] = $this->article_model->get_articles();
        $data['title'] = ucfirst($page); // Capitalize the first lette

        $this->load->view('template/header', $data);
        $this->load->view('pages/'.$page, $data);
        $this->load->view('template/footer', $data);
    }
}
